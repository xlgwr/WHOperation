namespace WHOperation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tfdnno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv1Pending = new System.Windows.Forms.DataGridView();
            this.DNNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POLine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vendor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PartNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MFGPartNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RIRNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PONumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ASNMFGPN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_urg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_loc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_msd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_cust_part = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_shelf_life = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_wt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_wt_ind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t_conn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrintedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RowID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.tfdndate = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.cbsystem = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cbfiltertype = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgv3VendorTemplate = new System.Windows.Forms.DataGridView();
            this.TempID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tab3_QRBar = new System.Windows.Forms.TabControl();
            this.tabPage5_OldQRBar = new System.Windows.Forms.TabPage();
            this.bStop = new System.Windows.Forms.Button();
            this.bEnableScan = new System.Windows.Forms.Button();
            this.tfscanarea = new System.Windows.Forms.TextBox();
            this.bDisableScan = new System.Windows.Forms.Button();
            this.bStart = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.tfnooflabels = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tfnoofcartons = new System.Windows.Forms.TextBox();
            this.list1boxSplit = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chk6Ohter = new System.Windows.Forms.CheckBox();
            this.txt5SplitOther = new System.Windows.Forms.TextBox();
            this.chk0dh = new System.Windows.Forms.CheckBox();
            this.chk7_3n2 = new System.Windows.Forms.CheckBox();
            this.chk3xh = new System.Windows.Forms.CheckBox();
            this.chk3Space = new System.Windows.Forms.CheckBox();
            this.chk5_3n1 = new System.Windows.Forms.CheckBox();
            this.chk1jh = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.listbox0ScanData = new System.Windows.Forms.ListBox();
            this.ldnpartnumber = new System.Windows.Forms.Label();
            this.lrecmfgpart = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lexpiredate = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.llotnumber = new System.Windows.Forms.Label();
            this.lMRecPartNumber = new System.Windows.Forms.Label();
            this.lMExpireDate = new System.Windows.Forms.Label();
            this.lMLotNumber = new System.Windows.Forms.Label();
            this.pbdnpartnumber = new System.Windows.Forms.PictureBox();
            this.tfdnpartnumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tfsite = new System.Windows.Forms.TextBox();
            this.pbexpiredate = new System.Windows.Forms.PictureBox();
            this.pblotnumber = new System.Windows.Forms.PictureBox();
            this.pbrecmfgpart = new System.Windows.Forms.PictureBox();
            this.pbrecqty = new System.Windows.Forms.PictureBox();
            this.pbmfgdate = new System.Windows.Forms.PictureBox();
            this.pbdatecode = new System.Windows.Forms.PictureBox();
            this.tfrecmfgrpart = new System.Windows.Forms.TextBox();
            this.tfexpiredate = new System.Windows.Forms.TextBox();
            this.tfmfgdate = new System.Windows.Forms.TextBox();
            this.tfhdndate = new System.Windows.Forms.TextBox();
            this.lmfgdate = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tfdnqty = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tfcumqty = new System.Windows.Forms.TextBox();
            this.tfdatecode = new System.Windows.Forms.TextBox();
            this.tfmfgpart = new System.Windows.Forms.TextBox();
            this.tfrirno = new System.Windows.Forms.TextBox();
            this.tfrecqty = new System.Windows.Forms.TextBox();
            this.tflotno = new System.Windows.Forms.TextBox();
            this.tfpartno = new System.Windows.Forms.TextBox();
            this.tfvendor = new System.Windows.Forms.TextBox();
            this.ldatecode = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lrecqty = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lMRecMfgPart = new System.Windows.Forms.Label();
            this.lMRecQty = new System.Windows.Forms.Label();
            this.lMDateCode = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lStatus = new System.Windows.Forms.Label();
            this.cbtrimmfgpart = new System.Windows.Forms.CheckBox();
            this.cbprintcartonlabel = new System.Windows.Forms.CheckBox();
            this.cbSmartScan = new System.Windows.Forms.CheckBox();
            this.cbAutoPrint = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cbprintertype = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cbport = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reStartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.btn2PIID = new System.Windows.Forms.Button();
            this.txt1PIID = new System.Windows.Forms.TextBox();
            this.chk5NoSplit = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tftodndate = new System.Windows.Forms.DateTimePicker();
            this.bGo = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgv0DNNumber = new System.Windows.Forms.DataGridView();
            this.DNNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl2_pending = new System.Windows.Forms.TabControl();
            this.tabPage3DNPending = new System.Windows.Forms.TabPage();
            this.tabPage4Comping = new System.Windows.Forms.TabPage();
            this.dgv1Complete = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage5PIpending = new System.Windows.Forms.TabPage();
            this.dgv5PIPending = new System.Windows.Forms.DataGridView();
            this.tabPage3Compele = new System.Windows.Forms.TabPage();
            this.dgv6PICompele = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tool_lbl_Msg = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1Pending)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3VendorTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tab3_QRBar.SuspendLayout();
            this.tabPage5_OldQRBar.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbdnpartnumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbexpiredate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pblotnumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrecmfgpart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrecqty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbmfgdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdatecode)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv0DNNumber)).BeginInit();
            this.tabControl2_pending.SuspendLayout();
            this.tabPage3DNPending.SuspendLayout();
            this.tabPage4Comping.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1Complete)).BeginInit();
            this.tabPage5PIpending.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5PIPending)).BeginInit();
            this.tabPage3Compele.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6PICompele)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tfdnno
            // 
            this.tfdnno.Location = new System.Drawing.Point(206, 12);
            this.tfdnno.Name = "tfdnno";
            this.tfdnno.Size = new System.Drawing.Size(100, 21);
            this.tfdnno.TabIndex = 3;
            this.tfdnno.TextChanged += new System.EventHandler(this.tfdnno_TextChanged);
            this.tfdnno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tfdnno_KeyDown);
            this.tfdnno.Leave += new System.EventHandler(this.tfdnno_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(137, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Supplier ID";
            // 
            // dgv1Pending
            // 
            this.dgv1Pending.AllowUserToAddRows = false;
            this.dgv1Pending.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1Pending.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv1Pending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1Pending.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DNNo,
            this.POLine,
            this.Vendor,
            this.PartNumber,
            this.MFGPartNo,
            this.RIRNo,
            this.PONumber,
            this.ASNMFGPN,
            this.DNQty,
            this.DNDate,
            this.DNSite,
            this.t_urg,
            this.t_loc,
            this.t_msd,
            this.t_cust_part,
            this.t_shelf_life,
            this.t_wt,
            this.t_wt_ind,
            this.t_conn,
            this.PrintedQty,
            this.RowID});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv1Pending.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv1Pending.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv1Pending.Location = new System.Drawing.Point(3, 3);
            this.dgv1Pending.MultiSelect = false;
            this.dgv1Pending.Name = "dgv1Pending";
            this.dgv1Pending.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1Pending.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv1Pending.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv1Pending.Size = new System.Drawing.Size(745, 127);
            this.dgv1Pending.TabIndex = 0;
            // 
            // DNNo
            // 
            this.DNNo.HeaderText = "DN-No";
            this.DNNo.Name = "DNNo";
            this.DNNo.ReadOnly = true;
            this.DNNo.Visible = false;
            this.DNNo.Width = 60;
            // 
            // POLine
            // 
            this.POLine.HeaderText = "Line";
            this.POLine.Name = "POLine";
            this.POLine.ReadOnly = true;
            this.POLine.Visible = false;
            this.POLine.Width = 30;
            // 
            // Vendor
            // 
            this.Vendor.HeaderText = "Vendor";
            this.Vendor.Name = "Vendor";
            this.Vendor.ReadOnly = true;
            this.Vendor.Visible = false;
            this.Vendor.Width = 60;
            // 
            // PartNumber
            // 
            this.PartNumber.HeaderText = "PartNumber";
            this.PartNumber.Name = "PartNumber";
            this.PartNumber.ReadOnly = true;
            this.PartNumber.Width = 130;
            // 
            // MFGPartNo
            // 
            this.MFGPartNo.HeaderText = "PO QPL-Part No";
            this.MFGPartNo.Name = "MFGPartNo";
            this.MFGPartNo.ReadOnly = true;
            this.MFGPartNo.Width = 130;
            // 
            // RIRNo
            // 
            this.RIRNo.HeaderText = "RIR-No";
            this.RIRNo.Name = "RIRNo";
            this.RIRNo.ReadOnly = true;
            // 
            // PONumber
            // 
            this.PONumber.HeaderText = "PONumber";
            this.PONumber.Name = "PONumber";
            this.PONumber.ReadOnly = true;
            this.PONumber.Width = 65;
            // 
            // ASNMFGPN
            // 
            this.ASNMFGPN.HeaderText = "ASN MFG P/N";
            this.ASNMFGPN.Name = "ASNMFGPN";
            this.ASNMFGPN.ReadOnly = true;
            this.ASNMFGPN.Width = 110;
            // 
            // DNQty
            // 
            this.DNQty.HeaderText = "DNQty";
            this.DNQty.Name = "DNQty";
            this.DNQty.ReadOnly = true;
            this.DNQty.Width = 45;
            // 
            // DNDate
            // 
            this.DNDate.HeaderText = "DN-Date";
            this.DNDate.Name = "DNDate";
            this.DNDate.ReadOnly = true;
            this.DNDate.Visible = false;
            this.DNDate.Width = 60;
            // 
            // DNSite
            // 
            this.DNSite.HeaderText = "DNSite";
            this.DNSite.Name = "DNSite";
            this.DNSite.ReadOnly = true;
            this.DNSite.Visible = false;
            // 
            // t_urg
            // 
            this.t_urg.HeaderText = "t_urg";
            this.t_urg.Name = "t_urg";
            this.t_urg.ReadOnly = true;
            this.t_urg.Visible = false;
            // 
            // t_loc
            // 
            this.t_loc.HeaderText = "t_loc";
            this.t_loc.Name = "t_loc";
            this.t_loc.ReadOnly = true;
            this.t_loc.Visible = false;
            // 
            // t_msd
            // 
            this.t_msd.HeaderText = "t_msd";
            this.t_msd.Name = "t_msd";
            this.t_msd.ReadOnly = true;
            this.t_msd.Visible = false;
            // 
            // t_cust_part
            // 
            this.t_cust_part.HeaderText = "t_cust_part";
            this.t_cust_part.Name = "t_cust_part";
            this.t_cust_part.ReadOnly = true;
            this.t_cust_part.Visible = false;
            // 
            // t_shelf_life
            // 
            this.t_shelf_life.HeaderText = "t_shelf_life";
            this.t_shelf_life.Name = "t_shelf_life";
            this.t_shelf_life.ReadOnly = true;
            this.t_shelf_life.Visible = false;
            // 
            // t_wt
            // 
            this.t_wt.HeaderText = "t_wt";
            this.t_wt.Name = "t_wt";
            this.t_wt.ReadOnly = true;
            this.t_wt.Visible = false;
            // 
            // t_wt_ind
            // 
            this.t_wt_ind.HeaderText = "t_wt_ind";
            this.t_wt_ind.Name = "t_wt_ind";
            this.t_wt_ind.ReadOnly = true;
            this.t_wt_ind.Visible = false;
            // 
            // t_conn
            // 
            this.t_conn.HeaderText = "t_conn";
            this.t_conn.Name = "t_conn";
            this.t_conn.ReadOnly = true;
            this.t_conn.Visible = false;
            // 
            // PrintedQty
            // 
            this.PrintedQty.HeaderText = "PrintedQty";
            this.PrintedQty.Name = "PrintedQty";
            this.PrintedQty.ReadOnly = true;
            this.PrintedQty.Width = 80;
            // 
            // RowID
            // 
            this.RowID.HeaderText = "RowID";
            this.RowID.Name = "RowID";
            this.RowID.ReadOnly = true;
            this.RowID.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(310, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 4;
            this.label14.Text = "DN Date";
            // 
            // tfdndate
            // 
            this.tfdndate.CustomFormat = "MM/dd/yy";
            this.tfdndate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tfdndate.Location = new System.Drawing.Point(365, 12);
            this.tfdndate.Name = "tfdndate";
            this.tfdndate.Size = new System.Drawing.Size(98, 21);
            this.tfdndate.TabIndex = 5;
            this.tfdndate.Value = new System.DateTime(2013, 6, 5, 10, 23, 0, 0);
            this.tfdndate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tfdndate_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "System";
            // 
            // cbsystem
            // 
            this.cbsystem.Location = new System.Drawing.Point(65, 12);
            this.cbsystem.Name = "cbsystem";
            this.cbsystem.ReadOnly = true;
            this.cbsystem.Size = new System.Drawing.Size(71, 21);
            this.cbsystem.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(876, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Filter";
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(1103, 5);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(28, 24);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Captured Image";
            this.groupBox3.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(988, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(124, 21);
            this.textBox2.TabIndex = 9;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // cbfiltertype
            // 
            this.cbfiltertype.FormattingEnabled = true;
            this.cbfiltertype.Items.AddRange(new object[] {
            "Part Number",
            "Mfgr Part Number"});
            this.cbfiltertype.Location = new System.Drawing.Point(911, 12);
            this.cbfiltertype.Name = "cbfiltertype";
            this.cbfiltertype.Size = new System.Drawing.Size(78, 20);
            this.cbfiltertype.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 206);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1101, 356);
            this.tabControl1.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1093, 330);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Vendor Template";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgv3VendorTemplate);
            this.groupBox4.Controls.Add(this.pb1);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1087, 324);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vendor Template";
            // 
            // dgv3VendorTemplate
            // 
            this.dgv3VendorTemplate.AllowUserToAddRows = false;
            this.dgv3VendorTemplate.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv3VendorTemplate.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv3VendorTemplate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv3VendorTemplate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TempID});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv3VendorTemplate.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgv3VendorTemplate.Location = new System.Drawing.Point(11, 18);
            this.dgv3VendorTemplate.Name = "dgv3VendorTemplate";
            this.dgv3VendorTemplate.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv3VendorTemplate.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv3VendorTemplate.Size = new System.Drawing.Size(142, 216);
            this.dgv3VendorTemplate.TabIndex = 0;
            // 
            // TempID
            // 
            this.TempID.HeaderText = "TemplateID";
            this.TempID.Name = "TempID";
            this.TempID.ReadOnly = true;
            this.TempID.Width = 70;
            // 
            // pb1
            // 
            this.pb1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb1.Location = new System.Drawing.Point(165, 18);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(305, 214);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1093, 330);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Capture PIMS Data";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.splitContainer2);
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.lStatus);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1087, 324);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PIMS Data Capture";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(3, 17);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.tab3_QRBar);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.AutoScroll = true;
            this.splitContainer2.Panel2.Controls.Add(this.list1boxSplit);
            this.splitContainer2.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer2.Panel2.Controls.Add(this.listbox0ScanData);
            this.splitContainer2.Panel2.Controls.Add(this.ldnpartnumber);
            this.splitContainer2.Panel2.Controls.Add(this.lrecmfgpart);
            this.splitContainer2.Panel2.Controls.Add(this.label12);
            this.splitContainer2.Panel2.Controls.Add(this.lexpiredate);
            this.splitContainer2.Panel2.Controls.Add(this.label8);
            this.splitContainer2.Panel2.Controls.Add(this.llotnumber);
            this.splitContainer2.Panel2.Controls.Add(this.lMRecPartNumber);
            this.splitContainer2.Panel2.Controls.Add(this.lMExpireDate);
            this.splitContainer2.Panel2.Controls.Add(this.lMLotNumber);
            this.splitContainer2.Panel2.Controls.Add(this.pbdnpartnumber);
            this.splitContainer2.Panel2.Controls.Add(this.tfdnpartnumber);
            this.splitContainer2.Panel2.Controls.Add(this.label5);
            this.splitContainer2.Panel2.Controls.Add(this.tfsite);
            this.splitContainer2.Panel2.Controls.Add(this.pbexpiredate);
            this.splitContainer2.Panel2.Controls.Add(this.pblotnumber);
            this.splitContainer2.Panel2.Controls.Add(this.pbrecmfgpart);
            this.splitContainer2.Panel2.Controls.Add(this.pbrecqty);
            this.splitContainer2.Panel2.Controls.Add(this.pbmfgdate);
            this.splitContainer2.Panel2.Controls.Add(this.pbdatecode);
            this.splitContainer2.Panel2.Controls.Add(this.tfrecmfgrpart);
            this.splitContainer2.Panel2.Controls.Add(this.tfexpiredate);
            this.splitContainer2.Panel2.Controls.Add(this.tfmfgdate);
            this.splitContainer2.Panel2.Controls.Add(this.tfhdndate);
            this.splitContainer2.Panel2.Controls.Add(this.lmfgdate);
            this.splitContainer2.Panel2.Controls.Add(this.label20);
            this.splitContainer2.Panel2.Controls.Add(this.tfdnqty);
            this.splitContainer2.Panel2.Controls.Add(this.label13);
            this.splitContainer2.Panel2.Controls.Add(this.tfcumqty);
            this.splitContainer2.Panel2.Controls.Add(this.tfdatecode);
            this.splitContainer2.Panel2.Controls.Add(this.tfmfgpart);
            this.splitContainer2.Panel2.Controls.Add(this.tfrirno);
            this.splitContainer2.Panel2.Controls.Add(this.tfrecqty);
            this.splitContainer2.Panel2.Controls.Add(this.tflotno);
            this.splitContainer2.Panel2.Controls.Add(this.tfpartno);
            this.splitContainer2.Panel2.Controls.Add(this.tfvendor);
            this.splitContainer2.Panel2.Controls.Add(this.ldatecode);
            this.splitContainer2.Panel2.Controls.Add(this.label7);
            this.splitContainer2.Panel2.Controls.Add(this.lrecqty);
            this.splitContainer2.Panel2.Controls.Add(this.label4);
            this.splitContainer2.Panel2.Controls.Add(this.label3);
            this.splitContainer2.Panel2.Controls.Add(this.lMRecMfgPart);
            this.splitContainer2.Panel2.Controls.Add(this.lMRecQty);
            this.splitContainer2.Panel2.Controls.Add(this.lMDateCode);
            this.splitContainer2.Size = new System.Drawing.Size(1081, 304);
            this.splitContainer2.SplitterDistance = 269;
            this.splitContainer2.TabIndex = 0;
            // 
            // tab3_QRBar
            // 
            this.tab3_QRBar.Controls.Add(this.tabPage5_OldQRBar);
            this.tab3_QRBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab3_QRBar.Location = new System.Drawing.Point(0, 0);
            this.tab3_QRBar.Name = "tab3_QRBar";
            this.tab3_QRBar.SelectedIndex = 0;
            this.tab3_QRBar.Size = new System.Drawing.Size(269, 304);
            this.tab3_QRBar.TabIndex = 6;
            // 
            // tabPage5_OldQRBar
            // 
            this.tabPage5_OldQRBar.Controls.Add(this.bStop);
            this.tabPage5_OldQRBar.Controls.Add(this.bEnableScan);
            this.tabPage5_OldQRBar.Controls.Add(this.tfscanarea);
            this.tabPage5_OldQRBar.Controls.Add(this.bDisableScan);
            this.tabPage5_OldQRBar.Controls.Add(this.bStart);
            this.tabPage5_OldQRBar.Controls.Add(this.button1);
            this.tabPage5_OldQRBar.Controls.Add(this.label21);
            this.tabPage5_OldQRBar.Controls.Add(this.tfnooflabels);
            this.tabPage5_OldQRBar.Controls.Add(this.label10);
            this.tabPage5_OldQRBar.Controls.Add(this.tfnoofcartons);
            this.tabPage5_OldQRBar.Location = new System.Drawing.Point(4, 22);
            this.tabPage5_OldQRBar.Name = "tabPage5_OldQRBar";
            this.tabPage5_OldQRBar.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5_OldQRBar.Size = new System.Drawing.Size(261, 278);
            this.tabPage5_OldQRBar.TabIndex = 0;
            this.tabPage5_OldQRBar.Text = "Old QR Bar";
            this.tabPage5_OldQRBar.UseVisualStyleBackColor = true;
            // 
            // bStop
            // 
            this.bStop.Enabled = false;
            this.bStop.Location = new System.Drawing.Point(6, 31);
            this.bStop.Name = "bStop";
            this.bStop.Size = new System.Drawing.Size(78, 20);
            this.bStop.TabIndex = 1;
            this.bStop.Text = "Stop";
            this.bStop.UseVisualStyleBackColor = true;
            this.bStop.Click += new System.EventHandler(this.bStop_Click);
            // 
            // bEnableScan
            // 
            this.bEnableScan.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bEnableScan.ForeColor = System.Drawing.Color.Red;
            this.bEnableScan.Location = new System.Drawing.Point(6, 81);
            this.bEnableScan.Name = "bEnableScan";
            this.bEnableScan.Size = new System.Drawing.Size(78, 20);
            this.bEnableScan.TabIndex = 5;
            this.bEnableScan.Text = "Enable";
            this.bEnableScan.UseVisualStyleBackColor = true;
            this.bEnableScan.Click += new System.EventHandler(this.bEnableScan_Click);
            // 
            // tfscanarea
            // 
            this.tfscanarea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tfscanarea.Location = new System.Drawing.Point(1, 108);
            this.tfscanarea.Multiline = true;
            this.tfscanarea.Name = "tfscanarea";
            this.tfscanarea.Size = new System.Drawing.Size(256, 164);
            this.tfscanarea.TabIndex = 3;
            this.tfscanarea.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tfscanarea_KeyDown);
            // 
            // bDisableScan
            // 
            this.bDisableScan.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bDisableScan.ForeColor = System.Drawing.Color.Red;
            this.bDisableScan.Location = new System.Drawing.Point(6, 56);
            this.bDisableScan.Name = "bDisableScan";
            this.bDisableScan.Size = new System.Drawing.Size(78, 20);
            this.bDisableScan.TabIndex = 4;
            this.bDisableScan.Text = "Disable";
            this.bDisableScan.UseVisualStyleBackColor = true;
            this.bDisableScan.Click += new System.EventHandler(this.bDisableScan_Click);
            // 
            // bStart
            // 
            this.bStart.Location = new System.Drawing.Point(6, 6);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(78, 20);
            this.bStart.TabIndex = 0;
            this.bStart.Text = "Start";
            this.bStart.UseVisualStyleBackColor = true;
            this.bStart.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("����", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(127, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 45);
            this.button1.TabIndex = 19;
            this.button1.Text = "Print";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label21.Location = new System.Drawing.Point(123, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 12);
            this.label21.TabIndex = 4;
            this.label21.Text = "No.Of Labels";
            // 
            // tfnooflabels
            // 
            this.tfnooflabels.BackColor = System.Drawing.Color.Yellow;
            this.tfnooflabels.Font = new System.Drawing.Font("����", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tfnooflabels.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tfnooflabels.Location = new System.Drawing.Point(206, 6);
            this.tfnooflabels.MaxLength = 3;
            this.tfnooflabels.Name = "tfnooflabels";
            this.tfnooflabels.Size = new System.Drawing.Size(39, 23);
            this.tfnooflabels.TabIndex = 17;
            this.tfnooflabels.Text = "1";
            this.tfnooflabels.TextChanged += new System.EventHandler(this.tfnooflabels_TextChanged);
            this.tfnooflabels.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tfnooflabels_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(105, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 12);
            this.label10.TabIndex = 60;
            this.label10.Text = "No.Of Carton(s)";
            // 
            // tfnoofcartons
            // 
            this.tfnoofcartons.BackColor = System.Drawing.Color.Yellow;
            this.tfnoofcartons.Font = new System.Drawing.Font("����", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tfnoofcartons.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tfnoofcartons.Location = new System.Drawing.Point(206, 30);
            this.tfnoofcartons.MaxLength = 3;
            this.tfnoofcartons.Name = "tfnoofcartons";
            this.tfnoofcartons.Size = new System.Drawing.Size(39, 23);
            this.tfnoofcartons.TabIndex = 18;
            this.tfnoofcartons.Text = "1";
            this.tfnoofcartons.TextChanged += new System.EventHandler(this.tfnoofcartons_TextChanged);
            this.tfnoofcartons.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tfnoofcartons_KeyDown);
            // 
            // list1boxSplit
            // 
            this.list1boxSplit.Font = new System.Drawing.Font("����", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.list1boxSplit.FormattingEnabled = true;
            this.list1boxSplit.HorizontalScrollbar = true;
            this.list1boxSplit.ItemHeight = 16;
            this.list1boxSplit.Location = new System.Drawing.Point(571, 148);
            this.list1boxSplit.Name = "list1boxSplit";
            this.list1boxSplit.ScrollAlwaysVisible = true;
            this.list1boxSplit.Size = new System.Drawing.Size(227, 148);
            this.list1boxSplit.TabIndex = 67;
            this.list1boxSplit.Click += new System.EventHandler(this.list1boxSplit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chk6Ohter);
            this.groupBox1.Controls.Add(this.txt5SplitOther);
            this.groupBox1.Controls.Add(this.chk0dh);
            this.groupBox1.Controls.Add(this.chk7_3n2);
            this.groupBox1.Controls.Add(this.chk3xh);
            this.groupBox1.Controls.Add(this.chk3Space);
            this.groupBox1.Controls.Add(this.chk5_3n1);
            this.groupBox1.Controls.Add(this.chk1jh);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(571, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(227, 90);
            this.groupBox1.TabIndex = 66;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "�ָ���";
            // 
            // chk6Ohter
            // 
            this.chk6Ohter.AutoSize = true;
            this.chk6Ohter.Location = new System.Drawing.Point(141, 63);
            this.chk6Ohter.Name = "chk6Ohter";
            this.chk6Ohter.Size = new System.Drawing.Size(15, 14);
            this.chk6Ohter.TabIndex = 68;
            this.chk6Ohter.UseVisualStyleBackColor = true;
            this.chk6Ohter.CheckedChanged += new System.EventHandler(this.chk6Ohter_CheckedChanged);
            // 
            // txt5SplitOther
            // 
            this.txt5SplitOther.Location = new System.Drawing.Point(42, 60);
            this.txt5SplitOther.Name = "txt5SplitOther";
            this.txt5SplitOther.Size = new System.Drawing.Size(93, 21);
            this.txt5SplitOther.TabIndex = 66;
            this.txt5SplitOther.TextChanged += new System.EventHandler(this.txt5SplitOther_TextChanged);
            this.txt5SplitOther.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt5SplitOther_KeyDown);
            // 
            // chk0dh
            // 
            this.chk0dh.AutoSize = true;
            this.chk0dh.Location = new System.Drawing.Point(6, 20);
            this.chk0dh.Name = "chk0dh";
            this.chk0dh.Size = new System.Drawing.Size(66, 16);
            this.chk0dh.TabIndex = 65;
            this.chk0dh.Text = "����(,)";
            this.chk0dh.UseVisualStyleBackColor = true;
            this.chk0dh.CheckedChanged += new System.EventHandler(this.chk0dh_CheckedChanged);
            // 
            // chk7_3n2
            // 
            this.chk7_3n2.AutoSize = true;
            this.chk7_3n2.Location = new System.Drawing.Point(156, 41);
            this.chk7_3n2.Name = "chk7_3n2";
            this.chk7_3n2.Size = new System.Drawing.Size(42, 16);
            this.chk7_3n2.TabIndex = 65;
            this.chk7_3n2.Text = "3N2";
            this.chk7_3n2.UseVisualStyleBackColor = true;
            this.chk7_3n2.CheckedChanged += new System.EventHandler(this.chk7_3n2_CheckedChanged);
            // 
            // chk3xh
            // 
            this.chk3xh.AutoSize = true;
            this.chk3xh.Location = new System.Drawing.Point(79, 41);
            this.chk3xh.Name = "chk3xh";
            this.chk3xh.Size = new System.Drawing.Size(66, 16);
            this.chk3xh.TabIndex = 65;
            this.chk3xh.Text = "�Ǻ�(*)";
            this.chk3xh.UseVisualStyleBackColor = true;
            this.chk3xh.CheckedChanged += new System.EventHandler(this.chk3xh_CheckedChanged);
            // 
            // chk3Space
            // 
            this.chk3Space.AutoSize = true;
            this.chk3Space.Location = new System.Drawing.Point(6, 42);
            this.chk3Space.Name = "chk3Space";
            this.chk3Space.Size = new System.Drawing.Size(48, 16);
            this.chk3Space.TabIndex = 65;
            this.chk3Space.Text = "�ظ�";
            this.chk3Space.UseVisualStyleBackColor = true;
            this.chk3Space.CheckedChanged += new System.EventHandler(this.chk3Space_CheckedChanged);
            // 
            // chk5_3n1
            // 
            this.chk5_3n1.AutoSize = true;
            this.chk5_3n1.Location = new System.Drawing.Point(155, 20);
            this.chk5_3n1.Name = "chk5_3n1";
            this.chk5_3n1.Size = new System.Drawing.Size(42, 16);
            this.chk5_3n1.TabIndex = 65;
            this.chk5_3n1.Text = "3N1";
            this.chk5_3n1.UseVisualStyleBackColor = true;
            this.chk5_3n1.CheckedChanged += new System.EventHandler(this.chk5_3n1_CheckedChanged);
            // 
            // chk1jh
            // 
            this.chk1jh.AutoSize = true;
            this.chk1jh.Location = new System.Drawing.Point(78, 20);
            this.chk1jh.Name = "chk1jh";
            this.chk1jh.Size = new System.Drawing.Size(66, 16);
            this.chk1jh.TabIndex = 65;
            this.chk1jh.Text = "����(-)";
            this.chk1jh.UseVisualStyleBackColor = true;
            this.chk1jh.CheckedChanged += new System.EventHandler(this.chk1jh_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 67;
            this.label9.Text = "������";
            // 
            // listbox0ScanData
            // 
            this.listbox0ScanData.Font = new System.Drawing.Font("����", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listbox0ScanData.FormattingEnabled = true;
            this.listbox0ScanData.HorizontalScrollbar = true;
            this.listbox0ScanData.ItemHeight = 16;
            this.listbox0ScanData.Location = new System.Drawing.Point(285, 68);
            this.listbox0ScanData.Name = "listbox0ScanData";
            this.listbox0ScanData.ScrollAlwaysVisible = true;
            this.listbox0ScanData.Size = new System.Drawing.Size(280, 228);
            this.listbox0ScanData.TabIndex = 0;
            this.listbox0ScanData.Click += new System.EventHandler(this.listbox0ScanData_Click);
            this.listbox0ScanData.SelectedIndexChanged += new System.EventHandler(this.listbox0ScanData_SelectedIndexChanged);
            // 
            // ldnpartnumber
            // 
            this.ldnpartnumber.AutoSize = true;
            this.ldnpartnumber.Location = new System.Drawing.Point(14, 68);
            this.ldnpartnumber.Name = "ldnpartnumber";
            this.ldnpartnumber.Size = new System.Drawing.Size(107, 12);
            this.ldnpartnumber.TabIndex = 22;
            this.ldnpartnumber.Text = "1.Rec Part Number";
            // 
            // lrecmfgpart
            // 
            this.lrecmfgpart.AutoSize = true;
            this.lrecmfgpart.Location = new System.Drawing.Point(18, 94);
            this.lrecmfgpart.Name = "lrecmfgpart";
            this.lrecmfgpart.Size = new System.Drawing.Size(101, 12);
            this.lrecmfgpart.TabIndex = 26;
            this.lrecmfgpart.Text = "2.Rec.MfgrPartNo";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 276);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 12);
            this.label12.TabIndex = 38;
            this.label12.Text = "Cumulative Qty";
            this.label12.Visible = false;
            // 
            // lexpiredate
            // 
            this.lexpiredate.AutoSize = true;
            this.lexpiredate.Location = new System.Drawing.Point(36, 198);
            this.lexpiredate.Name = "lexpiredate";
            this.lexpiredate.Size = new System.Drawing.Size(83, 12);
            this.lexpiredate.TabIndex = 30;
            this.lexpiredate.Text = "5.Expire Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(254, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 12);
            this.label8.TabIndex = 16;
            this.label8.Text = "PO QPL Part No.";
            // 
            // llotnumber
            // 
            this.llotnumber.AutoSize = true;
            this.llotnumber.Location = new System.Drawing.Point(42, 224);
            this.llotnumber.Name = "llotnumber";
            this.llotnumber.Size = new System.Drawing.Size(77, 12);
            this.llotnumber.TabIndex = 34;
            this.llotnumber.Text = "6.Lot Number";
            // 
            // lMRecPartNumber
            // 
            this.lMRecPartNumber.AutoSize = true;
            this.lMRecPartNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMRecPartNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMRecPartNumber.Location = new System.Drawing.Point(2, 67);
            this.lMRecPartNumber.Name = "lMRecPartNumber";
            this.lMRecPartNumber.Size = new System.Drawing.Size(15, 20);
            this.lMRecPartNumber.TabIndex = 59;
            this.lMRecPartNumber.Text = "*";
            // 
            // lMExpireDate
            // 
            this.lMExpireDate.AutoSize = true;
            this.lMExpireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMExpireDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMExpireDate.Location = new System.Drawing.Point(22, 197);
            this.lMExpireDate.Name = "lMExpireDate";
            this.lMExpireDate.Size = new System.Drawing.Size(15, 20);
            this.lMExpireDate.TabIndex = 56;
            this.lMExpireDate.Text = "*";
            this.lMExpireDate.Visible = false;
            // 
            // lMLotNumber
            // 
            this.lMLotNumber.AutoSize = true;
            this.lMLotNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMLotNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMLotNumber.Location = new System.Drawing.Point(28, 223);
            this.lMLotNumber.Name = "lMLotNumber";
            this.lMLotNumber.Size = new System.Drawing.Size(15, 20);
            this.lMLotNumber.TabIndex = 54;
            this.lMLotNumber.Text = "*";
            this.lMLotNumber.Visible = false;
            // 
            // pbdnpartnumber
            // 
            this.pbdnpartnumber.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbdnpartnumber.Location = new System.Drawing.Point(250, 66);
            this.pbdnpartnumber.Name = "pbdnpartnumber";
            this.pbdnpartnumber.Size = new System.Drawing.Size(29, 18);
            this.pbdnpartnumber.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbdnpartnumber.TabIndex = 53;
            this.pbdnpartnumber.TabStop = false;
            // 
            // tfdnpartnumber
            // 
            this.tfdnpartnumber.Location = new System.Drawing.Point(124, 64);
            this.tfdnpartnumber.Name = "tfdnpartnumber";
            this.tfdnpartnumber.Size = new System.Drawing.Size(123, 21);
            this.tfdnpartnumber.TabIndex = 26;
            this.tfdnpartnumber.TextChanged += new System.EventHandler(this.tfdnpartnumber_TextChanged);
            this.tfdnpartnumber.Enter += new System.EventHandler(this.tfdnpartnumber_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(525, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 20;
            this.label5.Text = "Site";
            // 
            // tfsite
            // 
            this.tfsite.Location = new System.Drawing.Point(571, 8);
            this.tfsite.Name = "tfsite";
            this.tfsite.Size = new System.Drawing.Size(123, 21);
            this.tfsite.TabIndex = 24;
            // 
            // pbexpiredate
            // 
            this.pbexpiredate.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbexpiredate.Location = new System.Drawing.Point(250, 195);
            this.pbexpiredate.Name = "pbexpiredate";
            this.pbexpiredate.Size = new System.Drawing.Size(29, 18);
            this.pbexpiredate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbexpiredate.TabIndex = 47;
            this.pbexpiredate.TabStop = false;
            // 
            // pblotnumber
            // 
            this.pblotnumber.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pblotnumber.Location = new System.Drawing.Point(250, 222);
            this.pblotnumber.Name = "pblotnumber";
            this.pblotnumber.Size = new System.Drawing.Size(29, 18);
            this.pblotnumber.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pblotnumber.TabIndex = 46;
            this.pblotnumber.TabStop = false;
            // 
            // pbrecmfgpart
            // 
            this.pbrecmfgpart.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbrecmfgpart.Location = new System.Drawing.Point(250, 93);
            this.pbrecmfgpart.Name = "pbrecmfgpart";
            this.pbrecmfgpart.Size = new System.Drawing.Size(29, 18);
            this.pbrecmfgpart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbrecmfgpart.TabIndex = 45;
            this.pbrecmfgpart.TabStop = false;
            // 
            // pbrecqty
            // 
            this.pbrecqty.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbrecqty.Location = new System.Drawing.Point(250, 121);
            this.pbrecqty.Name = "pbrecqty";
            this.pbrecqty.Size = new System.Drawing.Size(29, 18);
            this.pbrecqty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbrecqty.TabIndex = 44;
            this.pbrecqty.TabStop = false;
            // 
            // pbmfgdate
            // 
            this.pbmfgdate.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbmfgdate.Location = new System.Drawing.Point(250, 249);
            this.pbmfgdate.Name = "pbmfgdate";
            this.pbmfgdate.Size = new System.Drawing.Size(29, 18);
            this.pbmfgdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbmfgdate.TabIndex = 43;
            this.pbmfgdate.TabStop = false;
            // 
            // pbdatecode
            // 
            this.pbdatecode.Image = global::WHOperation.Properties.Resources.bdelete;
            this.pbdatecode.Location = new System.Drawing.Point(250, 168);
            this.pbdatecode.Name = "pbdatecode";
            this.pbdatecode.Size = new System.Drawing.Size(29, 18);
            this.pbdatecode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbdatecode.TabIndex = 42;
            this.pbdatecode.TabStop = false;
            // 
            // tfrecmfgrpart
            // 
            this.tfrecmfgrpart.Location = new System.Drawing.Point(124, 91);
            this.tfrecmfgrpart.Name = "tfrecmfgrpart";
            this.tfrecmfgrpart.Size = new System.Drawing.Size(123, 21);
            this.tfrecmfgrpart.TabIndex = 27;
            this.tfrecmfgrpart.TextChanged += new System.EventHandler(this.tfrecmfgrpart_TextChanged);
            this.tfrecmfgrpart.Enter += new System.EventHandler(this.tfrecmfgrpart_Enter);
            // 
            // tfexpiredate
            // 
            this.tfexpiredate.Location = new System.Drawing.Point(124, 193);
            this.tfexpiredate.MaxLength = 10;
            this.tfexpiredate.Name = "tfexpiredate";
            this.tfexpiredate.Size = new System.Drawing.Size(123, 21);
            this.tfexpiredate.TabIndex = 31;
            this.tfexpiredate.Enter += new System.EventHandler(this.tfexpiredate_Enter);
            // 
            // tfmfgdate
            // 
            this.tfmfgdate.Location = new System.Drawing.Point(124, 247);
            this.tfmfgdate.MaxLength = 10;
            this.tfmfgdate.Name = "tfmfgdate";
            this.tfmfgdate.Size = new System.Drawing.Size(123, 21);
            this.tfmfgdate.TabIndex = 33;
            this.tfmfgdate.Enter += new System.EventHandler(this.tfmfgdate_Enter);
            // 
            // tfhdndate
            // 
            this.tfhdndate.Location = new System.Drawing.Point(570, 36);
            this.tfhdndate.Name = "tfhdndate";
            this.tfhdndate.ReadOnly = true;
            this.tfhdndate.Size = new System.Drawing.Size(123, 21);
            this.tfhdndate.TabIndex = 25;
            // 
            // lmfgdate
            // 
            this.lmfgdate.AutoSize = true;
            this.lmfgdate.Location = new System.Drawing.Point(54, 250);
            this.lmfgdate.Name = "lmfgdate";
            this.lmfgdate.Size = new System.Drawing.Size(65, 12);
            this.lmfgdate.TabIndex = 28;
            this.lmfgdate.Text = "7.Mfg Date";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(513, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 18;
            this.label20.Text = "DN Date";
            // 
            // tfdnqty
            // 
            this.tfdnqty.Enabled = false;
            this.tfdnqty.Location = new System.Drawing.Point(124, 142);
            this.tfdnqty.Name = "tfdnqty";
            this.tfdnqty.Size = new System.Drawing.Size(123, 21);
            this.tfdnqty.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(78, 146);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 36;
            this.label13.Text = "DN Qty";
            // 
            // tfcumqty
            // 
            this.tfcumqty.Enabled = false;
            this.tfcumqty.Location = new System.Drawing.Point(124, 273);
            this.tfcumqty.Name = "tfcumqty";
            this.tfcumqty.Size = new System.Drawing.Size(123, 21);
            this.tfcumqty.TabIndex = 34;
            this.tfcumqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tfcumqty.Visible = false;
            // 
            // tfdatecode
            // 
            this.tfdatecode.Location = new System.Drawing.Point(124, 166);
            this.tfdatecode.MaxLength = 10;
            this.tfdatecode.Name = "tfdatecode";
            this.tfdatecode.Size = new System.Drawing.Size(123, 21);
            this.tfdatecode.TabIndex = 30;
            this.tfdatecode.Enter += new System.EventHandler(this.tfdatecode_Enter);
            // 
            // tfmfgpart
            // 
            this.tfmfgpart.Location = new System.Drawing.Point(353, 36);
            this.tfmfgpart.Name = "tfmfgpart";
            this.tfmfgpart.ReadOnly = true;
            this.tfmfgpart.Size = new System.Drawing.Size(123, 21);
            this.tfmfgpart.TabIndex = 23;
            // 
            // tfrirno
            // 
            this.tfrirno.Location = new System.Drawing.Point(124, 9);
            this.tfrirno.Name = "tfrirno";
            this.tfrirno.ReadOnly = true;
            this.tfrirno.Size = new System.Drawing.Size(123, 21);
            this.tfrirno.TabIndex = 20;
            // 
            // tfrecqty
            // 
            this.tfrecqty.Location = new System.Drawing.Point(124, 119);
            this.tfrecqty.Name = "tfrecqty";
            this.tfrecqty.Size = new System.Drawing.Size(123, 21);
            this.tfrecqty.TabIndex = 28;
            this.tfrecqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tfrecqty.TextChanged += new System.EventHandler(this.tfrecqty_TextChanged);
            this.tfrecqty.Enter += new System.EventHandler(this.tfrecqty_Enter);
            // 
            // tflotno
            // 
            this.tflotno.Location = new System.Drawing.Point(124, 220);
            this.tflotno.Name = "tflotno";
            this.tflotno.Size = new System.Drawing.Size(123, 21);
            this.tflotno.TabIndex = 32;
            this.tflotno.Enter += new System.EventHandler(this.tflotno_Enter);
            // 
            // tfpartno
            // 
            this.tfpartno.Location = new System.Drawing.Point(124, 37);
            this.tfpartno.Name = "tfpartno";
            this.tfpartno.ReadOnly = true;
            this.tfpartno.Size = new System.Drawing.Size(123, 21);
            this.tfpartno.TabIndex = 21;
            // 
            // tfvendor
            // 
            this.tfvendor.Location = new System.Drawing.Point(353, 8);
            this.tfvendor.Name = "tfvendor";
            this.tfvendor.ReadOnly = true;
            this.tfvendor.Size = new System.Drawing.Size(123, 21);
            this.tfvendor.TabIndex = 22;
            // 
            // ldatecode
            // 
            this.ldatecode.AutoSize = true;
            this.ldatecode.Location = new System.Drawing.Point(48, 172);
            this.ldatecode.Name = "ldatecode";
            this.ldatecode.Size = new System.Drawing.Size(71, 12);
            this.ldatecode.TabIndex = 24;
            this.ldatecode.Text = "4.Date Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "RIR Number";
            // 
            // lrecqty
            // 
            this.lrecqty.AutoSize = true;
            this.lrecqty.Location = new System.Drawing.Point(54, 120);
            this.lrecqty.Name = "lrecqty";
            this.lrecqty.Size = new System.Drawing.Size(65, 12);
            this.lrecqty.TabIndex = 32;
            this.lrecqty.Text = "3.Rec. Qty";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "Part Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(284, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "Vendor";
            // 
            // lMRecMfgPart
            // 
            this.lMRecMfgPart.AutoSize = true;
            this.lMRecMfgPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMRecMfgPart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMRecMfgPart.Location = new System.Drawing.Point(4, 93);
            this.lMRecMfgPart.Name = "lMRecMfgPart";
            this.lMRecMfgPart.Size = new System.Drawing.Size(15, 20);
            this.lMRecMfgPart.TabIndex = 57;
            this.lMRecMfgPart.Text = "*";
            this.lMRecMfgPart.Visible = false;
            // 
            // lMRecQty
            // 
            this.lMRecQty.AutoSize = true;
            this.lMRecQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMRecQty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMRecQty.Location = new System.Drawing.Point(41, 119);
            this.lMRecQty.Name = "lMRecQty";
            this.lMRecQty.Size = new System.Drawing.Size(15, 20);
            this.lMRecQty.TabIndex = 58;
            this.lMRecQty.Text = "*";
            // 
            // lMDateCode
            // 
            this.lMDateCode.AutoSize = true;
            this.lMDateCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lMDateCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lMDateCode.Location = new System.Drawing.Point(31, 171);
            this.lMDateCode.Name = "lMDateCode";
            this.lMDateCode.Size = new System.Drawing.Size(15, 20);
            this.lMDateCode.TabIndex = 55;
            this.lMDateCode.Text = "*";
            this.lMDateCode.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(50, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(506, 190);
            this.panel4.TabIndex = 1;
            // 
            // lStatus
            // 
            this.lStatus.AutoSize = true;
            this.lStatus.Location = new System.Drawing.Point(815, 0);
            this.lStatus.Name = "lStatus";
            this.lStatus.Size = new System.Drawing.Size(11, 12);
            this.lStatus.TabIndex = 0;
            this.lStatus.Text = ".";
            // 
            // cbtrimmfgpart
            // 
            this.cbtrimmfgpart.AutoSize = true;
            this.cbtrimmfgpart.Checked = true;
            this.cbtrimmfgpart.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbtrimmfgpart.Enabled = false;
            this.cbtrimmfgpart.Location = new System.Drawing.Point(929, 163);
            this.cbtrimmfgpart.Name = "cbtrimmfgpart";
            this.cbtrimmfgpart.Size = new System.Drawing.Size(102, 16);
            this.cbtrimmfgpart.TabIndex = 15;
            this.cbtrimmfgpart.Text = "Trim MFG Part";
            this.cbtrimmfgpart.UseVisualStyleBackColor = true;
            // 
            // cbprintcartonlabel
            // 
            this.cbprintcartonlabel.AutoSize = true;
            this.cbprintcartonlabel.Checked = true;
            this.cbprintcartonlabel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbprintcartonlabel.Location = new System.Drawing.Point(929, 139);
            this.cbprintcartonlabel.Name = "cbprintcartonlabel";
            this.cbprintcartonlabel.Size = new System.Drawing.Size(132, 16);
            this.cbprintcartonlabel.TabIndex = 14;
            this.cbprintcartonlabel.Text = "Print Carton Label";
            this.cbprintcartonlabel.UseVisualStyleBackColor = true;
            // 
            // cbSmartScan
            // 
            this.cbSmartScan.AutoSize = true;
            this.cbSmartScan.Checked = true;
            this.cbSmartScan.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSmartScan.Location = new System.Drawing.Point(929, 115);
            this.cbSmartScan.Name = "cbSmartScan";
            this.cbSmartScan.Size = new System.Drawing.Size(84, 16);
            this.cbSmartScan.TabIndex = 13;
            this.cbSmartScan.Text = "Smart Scan";
            this.cbSmartScan.UseVisualStyleBackColor = true;
            this.cbSmartScan.CheckedChanged += new System.EventHandler(this.cbSmartScan_CheckedChanged);
            // 
            // cbAutoPrint
            // 
            this.cbAutoPrint.AutoSize = true;
            this.cbAutoPrint.Checked = true;
            this.cbAutoPrint.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAutoPrint.Location = new System.Drawing.Point(929, 91);
            this.cbAutoPrint.Name = "cbAutoPrint";
            this.cbAutoPrint.Size = new System.Drawing.Size(84, 16);
            this.cbAutoPrint.TabIndex = 12;
            this.cbAutoPrint.Text = "Auto Print";
            this.cbAutoPrint.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(927, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 2;
            this.label16.Text = "Printer Type";
            // 
            // cbprintertype
            // 
            this.cbprintertype.FormattingEnabled = true;
            this.cbprintertype.Items.AddRange(new object[] {
            "TEC 200 dpi",
            "TEC, 300 dpi"});
            this.cbprintertype.Location = new System.Drawing.Point(1007, 64);
            this.cbprintertype.Name = "cbprintertype";
            this.cbprintertype.Size = new System.Drawing.Size(69, 20);
            this.cbprintertype.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(930, 41);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "Select Port";
            // 
            // cbport
            // 
            this.cbport.FormattingEnabled = true;
            this.cbport.Items.AddRange(new object[] {
            "LPT1",
            "COM1"});
            this.cbport.Location = new System.Drawing.Point(1007, 38);
            this.cbport.Name = "cbport";
            this.cbport.Size = new System.Drawing.Size(69, 20);
            this.cbport.TabIndex = 10;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.reStartToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(69, 48);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // reStartToolStripMenuItem
            // 
            this.reStartToolStripMenuItem.Name = "reStartToolStripMenuItem";
            this.reStartToolStripMenuItem.Size = new System.Drawing.Size(68, 22);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.btn2PIID);
            this.panel1.Controls.Add(this.txt1PIID);
            this.panel1.Controls.Add(this.chk5NoSplit);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.tftodndate);
            this.panel1.Controls.Add(this.bGo);
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Controls.Add(this.cbfiltertype);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cbsystem);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.tfdndate);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cbtrimmfgpart);
            this.panel1.Controls.Add(this.tfdnno);
            this.panel1.Controls.Add(this.cbAutoPrint);
            this.panel1.Controls.Add(this.cbSmartScan);
            this.panel1.Controls.Add(this.cbprintcartonlabel);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.cbport);
            this.panel1.Controls.Add(this.cbprintertype);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1115, 566);
            this.panel1.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(642, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 27;
            this.label11.Text = "PIID:";
            // 
            // btn2PIID
            // 
            this.btn2PIID.Location = new System.Drawing.Point(784, 11);
            this.btn2PIID.Name = "btn2PIID";
            this.btn2PIID.Size = new System.Drawing.Size(75, 23);
            this.btn2PIID.TabIndex = 26;
            this.btn2PIID.Text = "GO PIID";
            this.btn2PIID.UseVisualStyleBackColor = true;
            this.btn2PIID.Click += new System.EventHandler(this.btn2PIID_Click);
            // 
            // txt1PIID
            // 
            this.txt1PIID.Location = new System.Drawing.Point(679, 12);
            this.txt1PIID.Name = "txt1PIID";
            this.txt1PIID.Size = new System.Drawing.Size(100, 21);
            this.txt1PIID.TabIndex = 25;
            this.txt1PIID.TextChanged += new System.EventHandler(this.txt1PIID_TextChanged);
            // 
            // chk5NoSplit
            // 
            this.chk5NoSplit.AutoSize = true;
            this.chk5NoSplit.ForeColor = System.Drawing.Color.Red;
            this.chk5NoSplit.Location = new System.Drawing.Point(929, 187);
            this.chk5NoSplit.Name = "chk5NoSplit";
            this.chk5NoSplit.Size = new System.Drawing.Size(174, 16);
            this.chk5NoSplit.TabIndex = 16;
            this.chk5NoSplit.Text = "No Split Part or QPL-part";
            this.chk5NoSplit.UseVisualStyleBackColor = true;
            this.chk5NoSplit.CheckedChanged += new System.EventHandler(this.chk5NoSplit_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(469, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 24;
            this.label6.Text = "-";
            // 
            // tftodndate
            // 
            this.tftodndate.CustomFormat = "MM/dd/yy";
            this.tftodndate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tftodndate.Location = new System.Drawing.Point(485, 12);
            this.tftodndate.Name = "tftodndate";
            this.tftodndate.Size = new System.Drawing.Size(98, 21);
            this.tftodndate.TabIndex = 6;
            this.tftodndate.Value = new System.DateTime(2013, 6, 21, 10, 23, 0, 0);
            this.tftodndate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tftodndate_KeyDown);
            // 
            // bGo
            // 
            this.bGo.Location = new System.Drawing.Point(586, 12);
            this.bGo.Name = "bGo";
            this.bGo.Size = new System.Drawing.Size(40, 21);
            this.bGo.TabIndex = 7;
            this.bGo.Text = "Go";
            this.bGo.UseVisualStyleBackColor = true;
            this.bGo.Click += new System.EventHandler(this.bGo_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(12, 41);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgv0DNNumber);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl2_pending);
            this.splitContainer1.Size = new System.Drawing.Size(912, 159);
            this.splitContainer1.SplitterDistance = 149;
            this.splitContainer1.TabIndex = 21;
            // 
            // dgv0DNNumber
            // 
            this.dgv0DNNumber.AllowUserToAddRows = false;
            this.dgv0DNNumber.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv0DNNumber.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv0DNNumber.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv0DNNumber.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DNNumber});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv0DNNumber.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgv0DNNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv0DNNumber.Location = new System.Drawing.Point(0, 0);
            this.dgv0DNNumber.Name = "dgv0DNNumber";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv0DNNumber.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv0DNNumber.Size = new System.Drawing.Size(149, 159);
            this.dgv0DNNumber.TabIndex = 0;
            // 
            // DNNumber
            // 
            this.DNNumber.HeaderText = "DNNumber";
            this.DNNumber.Name = "DNNumber";
            // 
            // tabControl2_pending
            // 
            this.tabControl2_pending.Controls.Add(this.tabPage3DNPending);
            this.tabControl2_pending.Controls.Add(this.tabPage4Comping);
            this.tabControl2_pending.Controls.Add(this.tabPage5PIpending);
            this.tabControl2_pending.Controls.Add(this.tabPage3Compele);
            this.tabControl2_pending.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2_pending.Location = new System.Drawing.Point(0, 0);
            this.tabControl2_pending.Name = "tabControl2_pending";
            this.tabControl2_pending.SelectedIndex = 0;
            this.tabControl2_pending.Size = new System.Drawing.Size(759, 159);
            this.tabControl2_pending.TabIndex = 1;
            // 
            // tabPage3DNPending
            // 
            this.tabPage3DNPending.Controls.Add(this.dgv1Pending);
            this.tabPage3DNPending.Location = new System.Drawing.Point(4, 22);
            this.tabPage3DNPending.Name = "tabPage3DNPending";
            this.tabPage3DNPending.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3DNPending.Size = new System.Drawing.Size(751, 133);
            this.tabPage3DNPending.TabIndex = 0;
            this.tabPage3DNPending.Text = "Pending";
            this.tabPage3DNPending.UseVisualStyleBackColor = true;
            // 
            // tabPage4Comping
            // 
            this.tabPage4Comping.Controls.Add(this.dgv1Complete);
            this.tabPage4Comping.Location = new System.Drawing.Point(4, 22);
            this.tabPage4Comping.Name = "tabPage4Comping";
            this.tabPage4Comping.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4Comping.Size = new System.Drawing.Size(751, 133);
            this.tabPage4Comping.TabIndex = 1;
            this.tabPage4Comping.Text = "Complete";
            this.tabPage4Comping.UseVisualStyleBackColor = true;
            // 
            // dgv1Complete
            // 
            this.dgv1Complete.AllowUserToAddRows = false;
            this.dgv1Complete.AllowUserToDeleteRows = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1Complete.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgv1Complete.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1Complete.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn20});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv1Complete.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgv1Complete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv1Complete.Location = new System.Drawing.Point(3, 3);
            this.dgv1Complete.MultiSelect = false;
            this.dgv1Complete.Name = "dgv1Complete";
            this.dgv1Complete.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("����", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1Complete.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgv1Complete.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv1Complete.Size = new System.Drawing.Size(745, 127);
            this.dgv1Complete.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "PartNumber";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 130;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "PONumber";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 65;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "PO QPL-Part No";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 130;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "ASN MFG P/N";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 110;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "RIR-No";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "DNQty";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 45;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "PrintedQty";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 80;
            // 
            // tabPage5PIpending
            // 
            this.tabPage5PIpending.Controls.Add(this.dgv5PIPending);
            this.tabPage5PIpending.Location = new System.Drawing.Point(4, 22);
            this.tabPage5PIpending.Name = "tabPage5PIpending";
            this.tabPage5PIpending.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5PIpending.Size = new System.Drawing.Size(751, 133);
            this.tabPage5PIpending.TabIndex = 2;
            this.tabPage5PIpending.Text = "PI Pending";
            this.tabPage5PIpending.UseVisualStyleBackColor = true;
            // 
            // dgv5PIPending
            // 
            this.dgv5PIPending.AllowUserToAddRows = false;
            this.dgv5PIPending.AllowUserToDeleteRows = false;
            this.dgv5PIPending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv5PIPending.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5PIPending.Location = new System.Drawing.Point(3, 3);
            this.dgv5PIPending.Name = "dgv5PIPending";
            this.dgv5PIPending.ReadOnly = true;
            this.dgv5PIPending.RowTemplate.Height = 23;
            this.dgv5PIPending.Size = new System.Drawing.Size(745, 127);
            this.dgv5PIPending.TabIndex = 0;
            // 
            // tabPage3Compele
            // 
            this.tabPage3Compele.Controls.Add(this.dgv6PICompele);
            this.tabPage3Compele.Location = new System.Drawing.Point(4, 22);
            this.tabPage3Compele.Name = "tabPage3Compele";
            this.tabPage3Compele.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3Compele.Size = new System.Drawing.Size(751, 133);
            this.tabPage3Compele.TabIndex = 3;
            this.tabPage3Compele.Text = "PI Compele";
            this.tabPage3Compele.UseVisualStyleBackColor = true;
            // 
            // dgv6PICompele
            // 
            this.dgv6PICompele.AllowUserToDeleteRows = false;
            this.dgv6PICompele.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv6PICompele.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6PICompele.Location = new System.Drawing.Point(3, 3);
            this.dgv6PICompele.Name = "dgv6PICompele";
            this.dgv6PICompele.ReadOnly = true;
            this.dgv6PICompele.RowTemplate.Height = 23;
            this.dgv6PICompele.Size = new System.Drawing.Size(745, 127);
            this.dgv6PICompele.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tool_lbl_Msg});
            this.statusStrip1.Location = new System.Drawing.Point(0, 544);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1115, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tool_lbl_Msg
            // 
            this.tool_lbl_Msg.ForeColor = System.Drawing.Color.Red;
            this.tool_lbl_Msg.Name = "tool_lbl_Msg";
            this.tool_lbl_Msg.Size = new System.Drawing.Size(0, 17);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 566);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PIMS Data Capture";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing_1);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1Pending)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3VendorTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.tab3_QRBar.ResumeLayout(false);
            this.tabPage5_OldQRBar.ResumeLayout(false);
            this.tabPage5_OldQRBar.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbdnpartnumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbexpiredate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pblotnumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrecmfgpart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrecqty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbmfgdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdatecode)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv0DNNumber)).EndInit();
            this.tabControl2_pending.ResumeLayout(false);
            this.tabPage3DNPending.ResumeLayout(false);
            this.tabPage4Comping.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1Complete)).EndInit();
            this.tabPage5PIpending.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5PIPending)).EndInit();
            this.tabPage3Compele.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6PICompele)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox tfdnno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv1Pending;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker tfdndate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox cbsystem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox cbfiltertype;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgv3VendorTemplate;
        private System.Windows.Forms.DataGridViewTextBoxColumn TempID;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button bStop;
        private System.Windows.Forms.Button bStart;
        public System.Windows.Forms.TextBox tfscanarea;
        private System.Windows.Forms.CheckBox cbSmartScan;
        private System.Windows.Forms.CheckBox cbAutoPrint;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tfsite;
        private System.Windows.Forms.PictureBox pbexpiredate;
        private System.Windows.Forms.PictureBox pblotnumber;
        private System.Windows.Forms.PictureBox pbrecmfgpart;
        private System.Windows.Forms.PictureBox pbrecqty;
        private System.Windows.Forms.PictureBox pbmfgdate;
        private System.Windows.Forms.PictureBox pbdatecode;
        private System.Windows.Forms.TextBox tfrecmfgrpart;
        private System.Windows.Forms.Label lrecmfgpart;
        private System.Windows.Forms.TextBox tfexpiredate;
        private System.Windows.Forms.TextBox tfmfgdate;
        private System.Windows.Forms.TextBox tfnooflabels;
        private System.Windows.Forms.TextBox tfhdndate;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lmfgdate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cbprintertype;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbport;
        private System.Windows.Forms.TextBox tfdnqty;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tfcumqty;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tfdatecode;
        private System.Windows.Forms.TextBox tfmfgpart;
        private System.Windows.Forms.TextBox tfrirno;
        private System.Windows.Forms.TextBox tfrecqty;
        private System.Windows.Forms.TextBox tflotno;
        private System.Windows.Forms.TextBox tfpartno;
        private System.Windows.Forms.TextBox tfvendor;
        private System.Windows.Forms.Label ldatecode;
        private System.Windows.Forms.Label lexpiredate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lrecqty;
        private System.Windows.Forms.Label llotnumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lStatus;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dgv0DNNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNNumber;
        private System.Windows.Forms.Button bGo;
        private System.Windows.Forms.Button bEnableScan;
        private System.Windows.Forms.Button bDisableScan;
        private System.Windows.Forms.CheckBox cbprintcartonlabel;
        private System.Windows.Forms.DateTimePicker tftodndate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label ldnpartnumber;
        private System.Windows.Forms.TextBox tfdnpartnumber;
        private System.Windows.Forms.PictureBox pbdnpartnumber;
        private System.Windows.Forms.Label lMLotNumber;
        private System.Windows.Forms.Label lMDateCode;
        private System.Windows.Forms.Label lMExpireDate;
        private System.Windows.Forms.Label lMRecMfgPart;
        private System.Windows.Forms.TabControl tabControl2_pending;
        private System.Windows.Forms.TabPage tabPage3DNPending;
        private System.Windows.Forms.TabPage tabPage4Comping;
        private System.Windows.Forms.DataGridView dgv1Complete;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.Label lMRecPartNumber;
        private System.Windows.Forms.Label lMRecQty;
        private System.Windows.Forms.TextBox tfnoofcartons;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox cbtrimmfgpart;
        private System.Windows.Forms.TabControl tab3_QRBar;
        private System.Windows.Forms.TabPage tabPage5_OldQRBar;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reStartToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn POLine;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn PartNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn MFGPartNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RIRNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PONumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ASNMFGPN;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNSite;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_urg;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_loc;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_msd;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_cust_part;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_shelf_life;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_wt;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_wt_ind;
        private System.Windows.Forms.DataGridViewTextBoxColumn t_conn;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrintedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RowID;
        private System.Windows.Forms.ListBox listbox0ScanData;
        private System.Windows.Forms.ListBox list1boxSplit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt5SplitOther;
        private System.Windows.Forms.CheckBox chk0dh;
        private System.Windows.Forms.CheckBox chk3xh;
        private System.Windows.Forms.CheckBox chk3Space;
        private System.Windows.Forms.CheckBox chk1jh;
        private System.Windows.Forms.CheckBox chk6Ohter;
        private System.Windows.Forms.CheckBox chk5NoSplit;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tool_lbl_Msg;
        private System.Windows.Forms.CheckBox chk7_3n2;
        private System.Windows.Forms.CheckBox chk5_3n1;
        private System.Windows.Forms.Button btn2PIID;
        private System.Windows.Forms.TextBox txt1PIID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage5PIpending;
        private System.Windows.Forms.DataGridView dgv5PIPending;
        private System.Windows.Forms.TabPage tabPage3Compele;
        private System.Windows.Forms.DataGridView dgv6PICompele;
    }
}

